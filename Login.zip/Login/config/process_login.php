<?php

include 'dbconfig.php';

$email = $_POST['email'];
$password = $_POST['password'];

$sql = "SELECT * FROM user WHERE email = '$email' AND password = '$password'";

$result = $conn->query($sql);

if($result->num_rows > 0){
    while($row = $result->fetch_assoc()){
        //when user is found on the dbase, redirect user to welcome.php
    header("location: welcome.php");
    }
}else{
    echo 'incorrect password or username';
}
?>