<?php
include 'dbconfig.php';
//we want to insert all our codes in our waawphp database

$username = $_POST['username'];
$email = $_POST['email'];
$password = $_POST['password'];
$confirmpass = $_POST['confirmpass'];


$sql = "INSERT INTO user (username,email,password,confirmpass) VALUES
 ('$username','$email','$password','$confirmpass')";

if($conn->query($sql) === TRUE){

    /*now we are going to redirect user after they have successfully
    created an account on our platform
    */
    header("Location: welcome.php");

};


?>